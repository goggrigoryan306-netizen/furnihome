import { useState } from "react";
import { Link, useParams } from "react-router";

import { products } from "../../data/products";

import "./style.css";
import { useCart } from "../../context/CartContext";
import { useWishlist } from "../../context/WishlistContext";

export const MyProductPage = () => {
    const { id } = useParams();

    const product = products.find(
        (item) => item.id === Number(id)
    );

    const { addToCart } = useCart();

    const {
        toggleWishlist,
        isInWishlist,
    } = useWishlist();

    const [quantity, setQuantity] = useState(1);
const [selectedImage, setSelectedImage] = useState(
  product?.image || ""
);
    if (!product) {
        return (
            <div className="product-not-found">
                <h1>Ապրանքը չի գտնվել</h1>

                <Link to="/">
                    ← Վերադառնալ գլխավոր էջ
                </Link>
            </div>
        );
    }

    const increaseQuantity = () => {
        setQuantity((prev) => prev + 1);
    };

    const decreaseQuantity = () => {
        setQuantity((prev) =>
            prev > 1 ? prev - 1 : 1
        );
    };

    return (
        <div className="product-page">
            {/* BREADCRUMB */}

            <div className="product-breadcrumb">
                <Link to="/">
                    Գլխավոր
                </Link>

                <span>/</span>

                <span>
                    {product.category}
                </span>

                <span>/</span>

                <strong>
                    {product.title}
                </strong>
            </div>

            {/* PRODUCT MAIN */}

            <section className="product-details">
                {/* IMAGES */}

                <div className="product-gallery">
                    <div className="product-thumbnails">
                        {product.images.map((image, index) => (
                            <button
                                key={index}
                                className={
                                    selectedImage === image
                                        ? "thumbnail active"
                                        : "thumbnail"
                                }
                                onClick={() =>
                                    setSelectedImage(image)
                                }
                            >
                                <img
                                    src={image}
                                    alt={`${product.title} ${index + 1}`}
                                />
                            </button>
                        ))}
                    </div>

                    <div className="product-main-image">
                        {product.badge && (
                            <span className="details-badge">
                                {product.badge}
                            </span>
                        )}

                        <img
                            src={selectedImage}
                            alt={product.title}
                        />
                    </div>
                </div>

                {/* INFO */}

                <div className="product-information">
                    <p className="details-category">
                        {product.category}
                    </p>

                    <h1>
                        {product.title}
                    </h1>

                    <div className="details-rating">
                        <span>
                            ★★★★★
                        </span>

                        <p>
                            4.9 (27 կարծիք)
                        </p>
                    </div>

                    <div className="details-price">
                        <strong>
                            {product.price.toLocaleString()} ֏
                        </strong>

                        {product.oldPrice && (
                            <del>
                                {product.oldPrice.toLocaleString()} ֏
                            </del>
                        )}
                    </div>

                    <p className="product-description">
                        {product.description}
                    </p>

                    <div className="stock-status">
                        {product.inStock ? (
                            <span className="in-stock">
                                ● Առկա է պահեստում
                            </span>
                        ) : (
                            <span className="out-stock">
                                ● Առկա չէ
                            </span>
                        )}
                    </div>

                    {/* COLOR */}

                    <div className="details-option">
                        <p>
                            Գույն
                        </p>

                        <div className="colors">
                            <button className="color beige"></button>
                            <button className="color gray"></button>
                            <button className="color black"></button>
                        </div>
                    </div>

                    {/* QUANTITY */}

                    <div className="quantity-wrapper">
                        <p>Քանակ</p>

                        <div className="quantity">
                            <button
                                type="button"
                                onClick={() =>
                                    setQuantity((prev) =>
                                        prev > 1 ? prev - 1 : 1
                                    )
                                }
                            >
                                −
                            </button>

                            <span>{quantity}</span>

                            <button
                                type="button"
                                onClick={() =>
                                    setQuantity((prev) => prev + 1)
                                }
                            >
                                +
                            </button>
                        </div>
                    </div>

                    {/* BUTTONS */}

                    <div className="product-buttons">
                        <button
                            className="add-cart-btn"
                            disabled={!product.inStock}
                            onClick={() => addToCart(product, quantity)}
                        >
                            🛒 Ավելացնել զամբյուղ
                        </button>

                        <button
                            type="button"
                            className={
                                isInWishlist(product.id)
                                    ? "wishlist-btn active"
                                    : "wishlist-btn"
                            }
                            onClick={() => toggleWishlist(product)}
                        >
                            {isInWishlist(product.id) ? "♥" : "♡"}
                        </button>
                    </div>

                    {/* DELIVERY */}

                    <div className="product-benefits">
                        <div>
                            <span>🚚</span>

                            <div>
                                <strong>
                                    Արագ առաքում
                                </strong>

                                <p>
                                    Առաքում ամբողջ Հայաստանում
                                </p>
                            </div>
                        </div>

                        <div>
                            <span>✓</span>

                            <div>
                                <strong>
                                    Երաշխիք
                                </strong>

                                <p>
                                    {product.warranty}
                                </p>
                            </div>
                        </div>

                        <div>
                            <span>↻</span>

                            <div>
                                <strong>
                                    Վերադարձ
                                </strong>

                                <p>
                                    14 օրվա ընթացքում
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* SPECIFICATIONS */}

            <section className="product-specifications">
                <div className="specifications-title">
                    <p>
                        PRODUCT DETAILS
                    </p>

                    <h2>
                        Ապրանքի մանրամասները
                    </h2>
                </div>

                <div className="specifications-grid">
                    <div>
                        <span>
                            Նյութ
                        </span>

                        <strong>
                            {product.material}
                        </strong>
                    </div>

                    <div>
                        <span>
                            Գույն
                        </span>

                        <strong>
                            {product.color}
                        </strong>
                    </div>

                    <div>
                        <span>
                            Լայնություն
                        </span>

                        <strong>
                            {product.width}
                        </strong>
                    </div>

                    <div>
                        <span>
                            Բարձրություն
                        </span>

                        <strong>
                            {product.height}
                        </strong>
                    </div>

                    <div>
                        <span>
                            Խորություն
                        </span>

                        <strong>
                            {product.depth}
                        </strong>
                    </div>

                    <div>
                        <span>
                            Երաշխիք
                        </span>

                        <strong>
                            {product.warranty}
                        </strong>
                    </div>
                </div>
            </section>
        </div>
    );
};