import { Link, useParams } from "react-router";
import { products } from "../../data/products";
import "./style.css";

const categoryNames = {
  sofas: "Բազմոցներ",
  bedroom: "Ննջասենյակ",
  tables: "Սեղաններ",
  chairs: "Աթոռներ",
};

export const MyCategoryPage = () => {
  const { category } = useParams();

  const filteredProducts = products.filter(
    (product) => product.categorySlug === category
  );

  const categoryTitle =
    categoryNames[category] || "Ապրանքներ";

  return (
    <div className="category-page">

      <section className="category-hero">
        <p>FURNIHOME</p>

        <h1>{categoryTitle}</h1>

        <span>
          Գտնվել է {filteredProducts.length} ապրանք
        </span>
      </section>

      <div className="category-container">

        <div className="category-top">
          <div>
            <p className="category-small">
              ՄԵՐ ՏԵՍԱԿԱՆԻՆ
            </p>

            <h2>{categoryTitle}</h2>
          </div>

          <Link to="/" className="back-home">
            ← Գլխավոր էջ
          </Link>
        </div>


        {filteredProducts.length > 0 ? (
          <div className="category-products-grid">

            {filteredProducts.map((product) => (
              <article
                className="category-product-card"
                key={product.id}
              >

                <Link to={`/product/${product.id}`}>

                  <div className="category-product-image">

                    <img
                      src={product.image}
                      alt={product.title}
                    />

                    {product.badge && (
                      <span className="category-product-badge">
                        {product.badge}
                      </span>
                    )}

                  </div>


                  <div className="category-product-info">

                    <p className="product-category-name">
                      {product.category}
                    </p>

                    <h3>{product.title}</h3>

                    <p className="product-description">
                      {product.description}
                    </p>


                    <div className="category-product-bottom">

                      <div className="category-price">
                        <strong>
                          {product.price.toLocaleString()} ֏
                        </strong>

                        {product.oldPrice && (
                          <del>
                            {product.oldPrice.toLocaleString()} ֏
                          </del>
                        )}
                      </div>

                      <span className="product-arrow">
                        →
                      </span>

                    </div>

                  </div>

                </Link>

              </article>
            ))}

          </div>
        ) : (
          <div className="no-products">
            <h2>Ապրանքներ չեն գտնվել</h2>

            <Link to="/">
              Վերադառնալ գլխավոր էջ
            </Link>
          </div>
        )}

      </div>

    </div>
  );
};