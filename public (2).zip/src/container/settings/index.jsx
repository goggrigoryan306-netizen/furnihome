import { useState } from "react";

import "./style.css";

export const MySettingsPage = () => {
  const [form, setForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] =
    useState(false);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setSuccess("");

    if (
      !form.currentPassword ||
      !form.newPassword ||
      !form.confirmPassword
    ) {
      setError("Լրացրեք բոլոր դաշտերը");
      return;
    }

    if (form.newPassword.length < 6) {
      setError(
        "Նոր գաղտնաբառը պետք է լինի առնվազն 6 նիշ"
      );

      return;
    }

    if (
      form.newPassword !==
      form.confirmPassword
    ) {
      setError(
        "Նոր գաղտնաբառերը չեն համընկնում"
      );

      return;
    }

    try {
      setLoading(true);

      const token =
        localStorage.getItem("token");

      const response = await fetch(
        "http://localhost:5000/api/auth/change-password",
        {
          method: "PUT",

          headers: {
            "Content-Type":
              "application/json",

            Authorization:
              `Bearer ${token}`,
          },

          body: JSON.stringify(form),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(data.message);
        return;
      }

      setSuccess(data.message);

      setForm({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    } catch (error) {
      console.log(error);

      setError(
        "Server-ի հետ կապի խնդիր"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="settings-page">
      <div className="settings-container">

        <h1>Կարգավորումներ</h1>

        <div className="password-card">
          <h2>Փոխել գաղտնաբառը</h2>

          <form onSubmit={handleSubmit}>

            <div className="settings-field">
              <label>
                Հին գաղտնաբառ
              </label>

              <input
                type="password"
                name="currentPassword"
                value={
                  form.currentPassword
                }
                onChange={handleChange}
                placeholder="Հին գաղտնաբառ"
              />
            </div>

            <div className="settings-field">
              <label>
                Նոր գաղտնաբառ
              </label>

              <input
                type="password"
                name="newPassword"
                value={
                  form.newPassword
                }
                onChange={handleChange}
                placeholder="Նոր գաղտնաբառ"
              />
            </div>

            <div className="settings-field">
              <label>
                Կրկնել նոր գաղտնաբառը
              </label>

              <input
                type="password"
                name="confirmPassword"
                value={
                  form.confirmPassword
                }
                onChange={handleChange}
                placeholder="Կրկնել նոր գաղտնաբառը"
              />
            </div>

            {error && (
              <p className="error-message">
                {error}
              </p>
            )}

            {success && (
              <p className="success-message">
                {success}
              </p>
            )}

            <button
              type="submit"
              className="change-password-button"
              disabled={loading}
            >
              {loading
                ? "Պահպանվում է..."
                : "Փոխել գաղտնաբառը"}
            </button>

          </form>
        </div>

      </div>
    </div>
  );
};