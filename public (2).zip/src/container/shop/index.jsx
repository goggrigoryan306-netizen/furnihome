import { useState } from "react";
import { Link } from "react-router";
import { products } from "../../data/products";
import "./style.css";
import { useWishlist } from "../../context/WishlistContext";

export const MyShopPage = () => {
  const [showAllProducts, setShowAllProducts] = useState(false);

  const {
    isInWishlist,
    toggleWishlist,
  } = useWishlist();

  const visibleProducts = showAllProducts
    ? products
    : products.slice(0, 4);

  return (
    <main className="shop-page">

      {/* SHOP HERO */}
      <section className="shop-hero">
        <div className="shop-hero-content">
          <p>FURNIHOME COLLECTION</p>

          <h1>Խանութ</h1>

          <span>
            Բացահայտիր ժամանակակից և որակյալ կահույքի մեր
            տեսականին։
          </span>
        </div>
      </section>


      {/* PRODUCTS */}
      <section className="shop-products">
        <div className="shop-products-header">
          <div>
            <p className="shop-small-title">
              ՄԵՐ ՏԵՍԱԿԱՆԻՆ
            </p>

            <h2>Ընտրիր քո կահույքը</h2>
          </div>

          <span className="shop-products-count">
            {products.length} ապրանք
          </span>
        </div>


        <div className="shop-products-grid">

          {visibleProducts.map((product) => (

            <article
              className="shop-product-card"
              key={product.id}
            >

              <Link to={`/product/${product.id}`}>

                <div className="product-image">

  <img
    src={product.image}
    alt={product.title}
  />

  {product.badge && (
    <span className="product-badge">
      {product.badge}
    </span>
  )}

  <button
    className={`favorite-btn ${
      isInWishlist(product.id) ? "saved" : ""
    }`}
    onClick={(e) => {
      e.preventDefault();
      e.stopPropagation();

      toggleWishlist(product);
    }}
  >
    {isInWishlist(product.id) ? "♥" : "♡"}
  </button>

</div>


                <div className="shop-product-content">

                  <p>{product.category}</p>

                  <h3>{product.title}</h3>


                  <div className="shop-product-price">

                    <strong>
                      {product.price.toLocaleString()} ֏
                    </strong>

                    {product.oldPrice && (
                      <del>
                        {product.oldPrice.toLocaleString()} ֏
                      </del>
                    )}

                  </div>


                  <span className="shop-view-product">
                    Դիտել ապրանքը →
                  </span>

                </div>

              </Link>

            </article>

          ))}

        </div>


        {/* VIEW ALL */}

        {products.length > 4 && (

          <div className="shop-view-all">

            <button
              onClick={() =>
                setShowAllProducts((prev) => !prev)
              }
            >

              {showAllProducts
                ? "Փակել տեսականին"
                : "Դիտել բոլորը"}

              <span>
                {showAllProducts ? "↑" : "→"}
              </span>

            </button>

          </div>

        )}

      </section>

    </main>
  );
};