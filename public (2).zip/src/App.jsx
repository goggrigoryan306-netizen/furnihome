import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router";

import { useEffect } from "react";
import "./style.css"
import { MyHomePage } from "./container/home";
import { MyContactPage } from "./container/contact";
import { MyProductPage } from "./container/product";
import { MyCartPage } from "./container/cart";

import { MyHeader } from "./components/header";
import { MyFooter } from "./components/footer";

import { CartProvider } from "./context/CartContext";
import { MyCategoryPage } from "./container/category";
import { MyProductsPage } from "./container/products";
import { MyShopPage } from "./container/shop";
import { MyAboutPage } from "./container/about";
import { WishlistProvider } from "./context/WishlistContext";
import { MyWishlistPage } from "./container/wishList";
import { MyRegisterPage } from "./container/register";
import { MyReviewsPage } from "./container/reviews";
import { MyDeliveryPage } from "./container/delivery";
import { MyPaymentPage } from "./container/payment";
import { MyWarrantyPage } from "./container/warranty";
import { MyReturnsPage } from "./container/returns";
import { MyFAQPage } from "./container/faq";
import { MyLoginPage } from "./container/register/MyLoginPage";
import { MySettingsPage } from "./container/settings";






function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "instant",
    });
  }, [pathname]);

  return null;
}

function App() {
  return (
    <WishlistProvider>
      <CartProvider>
        <Router>
          <ScrollToTop />

          <MyHeader />

          <main className="app-content">
            <Routes>
              <Route path="/" element={<MyHomePage />} />
              <Route path="/contact" element={<MyContactPage />} />
              <Route path="/product/:id" element={<MyProductPage />} />
              <Route path="/cart" element={<MyCartPage />} />
              <Route path="/products" element={<MyProductsPage />} />
              <Route path="/shop" element={<MyShopPage />} />
              <Route path="/about" element={<MyAboutPage />} />
              <Route path="/reviews" element={<MyReviewsPage />} />
              

              <Route
                path="/delivery"
                element={<MyDeliveryPage />}
              />

              <Route
                path="/payment"
                element={<MyPaymentPage />}
              />

              <Route
                path="/warranty"
                element={<MyWarrantyPage />}
              />

              <Route
                path="/returns"
                element={<MyReturnsPage />}
              />

              <Route
                path="/faq"
                element={<MyFAQPage />}
              />


              <Route
                path="/register"
                element={<MyRegisterPage />}
              />
              <Route
                path="/category/:category"
                element={<MyCategoryPage />}
              />
              <Route
                path="/wishlist"
                element={<MyWishlistPage />}
              />



              <Route
                path="/login"
                element={<MyLoginPage />}
              />

              <Route
  path="/settings"
  element={<MySettingsPage />}
/>



            </Routes>
          </main>

          <MyFooter />
        </Router>
      </CartProvider>
    </WishlistProvider>
  );
}

export default App;